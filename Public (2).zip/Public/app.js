const express = require('express');
const schedule = require('node-schedule');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const session = require('express-session');
const { promises: fsPromises } = require('fs');

const app = express();
const port = 3000;

const dataFilePath = path.join(__dirname, 'data.json');
const usersDataPath = path.join(__dirname, 'users.json');
const artworksDataPath = path.join(__dirname, 'artwork.json');
const eventsDataPath = path.join(__dirname, 'events.json');

// Set up EJS
app.set('view engine', 'ejs');

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer configuration for handling file uploads
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage: storage });

// Helper functions
async function geocodeAddress(address) {
  const headers = {
    'User-Agent': 'StreetArt/1.0 (kialanda.garcia@gmail.com)', // Replace with your app name and contact info
  };

  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`, { headers });
    const text = await response.text();

    let data;
    try {
      data = JSON.parse(text);
    } catch (jsonError) {
      throw new Error(`Invalid JSON response: ${text}`);
    }

    if (data && data.length > 0) {
      return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
    } else {
      const broaderResponse = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1&viewbox=-180,-90,180,90`, { headers });
      const broaderText = await broaderResponse.text();

      try {
        data = JSON.parse(broaderText);
      } catch (broaderJsonError) {
        throw new Error(`Invalid broader JSON response: ${broaderText}`);
      }

      if (data && data.length > 0) {
        return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
      }
    }
  } catch (error) {
    console.error('Error geocoding address:', error.message);
  }
  return null;
}

async function loadJson(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      await fsPromises.writeFile(filePath, '[]', 'utf8');
    }
    const data = await fsPromises.readFile(filePath, 'utf8');
    return JSON.parse(data) || [];
  } catch (error) {
    console.error(`Error reading ${filePath}:`, error);
    return [];
  }
}

async function saveJson(filePath, data) {
  try {
    await fsPromises.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error(`Error saving ${filePath}:`, error);
  }
}

// Function to load users from the JSON file
function loadUsers() {
  const data = fs.readFileSync(usersDataPath, 'utf8');
  return JSON.parse(data);
}

// Function to save users to the JSON file
function saveUsers(users) {
  fs.writeFileSync(usersDataPath, JSON.stringify(users, null, 2), 'utf8');
}

// Routes
app.get('/', async (req, res) => {
  const photos = await loadJson(artworksDataPath);
  res.render('home', { user: req.session.user, photos, imageDatabase: photos });
});

app.get('/about', (req, res) => {
  res.render('about');
});

app.get('/artwork', async (req, res) => {
  const users = await loadJson(usersDataPath);
  res.render('artwork', { user: req.session.user, users });
});

app.get('/calendar', async (req, res) => {
  const events = await loadJson(eventsDataPath);
  res.render('calendar', { events });
});

app.get('/users/:username', (req, res) => {
  res.render('users', { username: req.params.username });
});

app.get('/map', async (req, res) => {
  const users = await loadJson(usersDataPath);
  res.render('map', { user: req.session.user, users });
});

app.get('/api/artwork', async (req, res) => {
  try {
    const artworks = await loadJson(artworksDataPath);
    res.json(artworks);
  } catch (error) {
    console.error('Error fetching artwork data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



app.get('/signin', (req, res) => {
  res.render('signin');
});

app.get('/signup', (req, res) => {
  res.render('signup');
});

// Route to handle sign-up form submission
app.post('/signup', upload.single('profilePicture'), (req, res) => {
  const users = loadUsers();
  const hashedPassword = bcrypt.hashSync(req.body.password, 10);

  const newUser = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    username: req.body.username,
    location: req.body.location,
    link: req.body.link,
    email: req.body.email,
    password: hashedPassword,
    description: req.body.description,
    profilePicture: req.file ? req.file.filename : null,
  };

  users.push(newUser);
  saveUsers(users);

  req.session.user = newUser; // Set the user session
  res.redirect('/dashboard');
});

app.get('/description/:username/:filename', async (req, res) => {
  const users = await loadJson(usersDataPath);
  const { username, filename } = req.params;
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.redirect('/artwork');
  }
  const photo = user.photos.find(p => p.filename === filename);
  if (!photo) {
    return res.redirect('/artwork');
  }
  res.render('description', { user, photo });
});

// Route to handle sign-in form submission
app.post('/signin', async (req, res) => {
  const users = await loadJson(usersDataPath);
  const user = users.find(u => u.username === req.body.username);

  if (user && bcrypt.compareSync(req.body.password, user.password)) {
    req.session.user = user; // Set the user session
    res.redirect('/dashboard'); // Redirect to the dashboard
  } else {
    res.send('Invalid username or password. Please try again.');
  }
});

// Route for the dashboard
app.get('/dashboard', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/signin');
  }
  const users = await loadJson(usersDataPath);
  const userData = users.find(u => u.username === req.session.user.username);
  const artworkData = await loadJson(artworksDataPath);
  res.render('dashboard', { user: userData, photos: userData.photos || [], artworks: artworkData });
});

app.post('/uploadPhoto', upload.single('photo'), async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/signin');
  }
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }
  const { title, author, location: locationAddress, description } = req.body;
  const location = await geocodeAddress(locationAddress);
  if (!location) {
    return res.status(400).send('Location not found.');
  }
  const artworks = await loadJson(artworksDataPath);
  const newPhoto = {
    id: Date.now().toString(36) + Math.random().toString(36).substr(2),
    username: req.session.user.username,
    title,
    author,
    location: { type: 'Point', coordinates: location, address: locationAddress },
    description,
    filename: req.file.filename,
  };
  artworks.push(newPhoto);
  await saveJson(artworksDataPath, artworks);
  res.redirect('/dashboard');
});

app.post('/deletePhoto/:id', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/dashboard');
  }
  const artworks = await loadJson(artworksDataPath);
  const updatedArtworks = artworks.filter(photo => photo.id !== req.params.id);
  await saveJson(artworksDataPath, updatedArtworks);
  res.redirect('/dashboard');
});

app.post('/signout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
    }
    res.redirect('/signin');
  });
});

app.post('/add-event', upload.single('photo'), async (req, res) => {
  const { title, host, date, location, yourName, yourEmail, eventUrl, description } = req.body;
  const photoPath = req.file ? `/uploads/${req.file.filename}` : ''; // Save the file path

  try {
    const locationCoordinates = await geocodeAddress(location);
    if (!locationCoordinates) {
      return res.status(400).send('Location not found.');
    }

    const [lat, lon] = locationCoordinates;
    const events = await loadJson(eventsDataPath);

    const newEvent = {
      id: events.length + 1,
      title,
      host,
      date: new Date(date),
      location,
      yourName,
      yourEmail,
      eventUrl,
      description,
      photo: photoPath,
      latitude: lat,
      longitude: lon,
    };

    events.push(newEvent);
    await saveJson(eventsDataPath, events);

    res.redirect('/calendar');
  } catch (error) {
    console.error('Error adding event:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/event/:id', async (req, res) => {
  const events = await loadJson(eventsDataPath);
  const event = events.find(e => e.id === parseInt(req.params.id, 10));

  if (!event) {
    return res.status(404).send('Event not found');
  }

  res.render('event', { event });
});

// Middleware
const requireLogin = (req, res, next) => {
  if (!req.session.user) {
    res.redirect('/');
  } else {
    next();
  }
};

app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

app.get('/somepage', requireLogin, (req, res) => {
  res.render('somepage');
});

// Scheduling job to delete events after 10 days
schedule.scheduleJob('0 0 */240 * *', async () => {
  const events = await loadJson(eventsDataPath);
  const tenDaysAgo = new Date();
  tenDaysAgo.setDate(tenDaysAgo.getDate() - 10);

  const updatedEvents = events.filter(event => new Date(event.date) >= tenDaysAgo);
  await saveJson(eventsDataPath, updatedEvents);

  console.log('Expired events deleted');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
